local bola = script.Parent
local velocidade = 5

game["Run Service"].Heartbeat:Connect(function(delta)
	
	local alvo:BasePart
	local dist:number
	
	for _,player in game.Players:GetPlayers() do
		
		local model = player.Character
		
		if not model then continue end
		
		local novaDist = (model.WorldPivot.Position - bola.CFrame.Position).Magnitude
		
		if not dist or novaDist < dist then
			
			alvo = model:FindFirstChild("HumanoidRootPart")
			dist = novaDist
			
		end
		
	end
	
	if not alvo then return end
	
	local look = (alvo.CFrame.Position - bola.CFrame.Position).Unit
	
	bola.Position += look * delta * velocidade
	
	velocidade += delta
	
end)

bola.Touched:Connect(function(part)
	
	local model = part:FindFirstAncestorOfClass("Model")
	
	if not model then return end
	
	local hum:Humanoid = model:FindFirstChild("Humanoid")
	
	if not hum then return end
	
	hum.Health = 0
	
end)