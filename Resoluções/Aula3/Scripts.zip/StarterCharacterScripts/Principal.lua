local model:Model = script.Parent
local humanoid:Humanoid = model:FindFirstChild("Humanoid")

model:SetAttribute("Moedas",0)

model:GetAttributeChangedSignal("Moedas"):Connect(function()
	
	local moedas = model:GetAttribute("Moedas")
	
	humanoid.WalkSpeed = 16 * moedas
	
end)