local moeda = script.Parent

moeda.Touched:Connect(function(part)
	
	local model = part:FindFirstAncestorOfClass("Model")
	
	if not model then return end
	
	model:SetAttribute("Moedas",model:GetAttribute("Moedas") + 1)
	
	moeda:Destroy()
	
end)