local parede = script.Parent

for _,part in workspace:GetPartsInPart(parede) do
	
	local model = part:FindFirstAncestorOfClass("Model")

	if model then

		local hum:Humanoid = model:FindFirstChild("Humanoid")

		if hum then hum.Health = 0 end

		return

	end

	part:Destroy()
	
end