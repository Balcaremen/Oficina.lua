local moeda = game.ServerStorage.Moeda

while task.wait(3) do
	
	local newMoeda = moeda:Clone()
	newMoeda.Parent = workspace.Moedas
	
	local x = math.random(-50,50)
	local z = math.random(-50,50)
	
	newMoeda.Position = Vector3.new(x,5,z)
	
end