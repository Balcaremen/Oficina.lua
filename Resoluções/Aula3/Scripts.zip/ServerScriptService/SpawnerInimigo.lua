local bola = game.ServerStorage.Bola

while task.wait(10) do
	
	local newBola = bola:Clone()
	newBola.Parent = workspace.Inimigos
	
	local x = math.random(-50,50)
	local z = math.random(-50,50)
	
	newBola.Position = Vector3.new(x,5,z)
	
end