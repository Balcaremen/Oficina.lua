math.randomseed(os.time())

--Requerindo os módulos necessários
local Vetor = require "Vetor"
local Alvo = require "Alvo"

--Declarando as variáveis
local mouse = Vetor.new()
local pontos = 0
local tempo = 0
local alvos = {}
local jaApertado = false

function love.update()

    --Obtendo se o mouse está apertado
    local Novoapertado = love.mouse.isDown(1)
    local apertado = Novoapertado

    --Disabilitando se já estiver apertado antes
    if jaApertado then apertado = false end

    --Atualizando o "jaApertado"
    jaApertado = Novoapertado

    --Obtendo a largura e comprimento (altitude...)
    local largura,altitude = love.graphics.getDimensions()
    --Obtendo a posição x e y do mouse
    local x,y = love.mouse.getPosition()
    --Adicionando ao "mouse"
    mouse.x = x
    mouse.y = y

    --Correndo o tempo
    tempo = tempo + 1

    --Se o resto do tempo e 60 for igual a 0 ou, se o ciclo do tempo está exatamente em 60
    --Adicione o alvo em algum lugar aleatório
    if tempo % 60 == 0 then
        local novoAlvo = Alvo.new()
        novoAlvo.pos = Vetor.new(math.random(0,largura),math.random(0,altitude))
        --Inserindo o novo alvo na tabela alvos
        table.insert(alvos,novoAlvo)
    end

    --Se não estiver apertado, nem verifique se o mouse está colidindo

    if not apertado then return end

    --Verificação dos alvos colidindo com o mouse

    for id,alvo in pairs(alvos) do
        if alvo:colide(mouse) then
            ---Removendo o mouse da tabela alvos
            alvos[id] = nil
            ---Adicionando +1 ponto
            pontos = pontos + 1
        end
    end

end

function love.draw()
    ---Desenhar alvos
    for id,alvo in pairs(alvos) do
        alvo:draw()
    end
    ---Mostrar pontuação
    love.graphics.print("Pontos: "..pontos)
end