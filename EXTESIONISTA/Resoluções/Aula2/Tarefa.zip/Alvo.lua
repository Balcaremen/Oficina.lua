--Requerindo o módulo Vetor
local Vetor = require "Vetor"
--Declaração mais específica de uma "classe" em "Vetor.lua"
local Alvo = {}
Alvo.__index = Alvo
--Área padrão
Alvo.radius = 10

function Alvo.new()
    local alvo = {}
    --Declarando uma posição padrão que não seja global
    alvo.pos = Vetor.new()
    return setmetatable(alvo,Alvo)
end

--Verificação se um Vetor "Está na área" do alvo
function Alvo:colide(pos)
    --Se a distância entre o ponto e o alvo é menor que a área, então está dentro da área!
    return (self.pos - pos):total() < self.radius
end

--Função que desenha o alvo
function Alvo:draw()
    love.graphics.circle("line",self.pos.x,self.pos.y,self.radius)
end

return Alvo