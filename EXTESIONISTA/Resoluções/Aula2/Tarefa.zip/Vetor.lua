--Declarando a nova "classe"
local Vetor = {}
--Declarando __index para caso a tabela não tenha o valor no index, puxe então de Vetor
Vetor.__index = Vetor
--Declarando x e y padrão (Apenas para mostrar no editor, x e y já estão sendo declarados no new)
Vetor.x = 0
Vetor.y = 0

--Função no Vetor que cria uma nova "classe Vetor"
function Vetor.new(x,y)
    --Se x existe, então declare como x, senão, declare como 0
    --Qualquer valor que não seja nil ou false é verdadeiro
    --Caso seja mais expecífico, pode se usar "tonumber" (Como tostring só que para números)
    local v = {x = x or 0,y = y or 0}
    return setmetatable(v,Vetor)
end

--Função para retornar o valor total de x e y
function Vetor:total()
    return math.abs(self.x) + math.abs(self.y)
end

--Função para copiar o Vetor, e não reusar-lo
function Vetor:copy()
    return Vetor.new(self.x,self.y)
end

--Função para retornar mais facilemente x e y juntos (x,y)
function Vetor:unpack()
    return self.x,self.y
end

--Operadores do Vetor:
--Caso precise que um Vetor possa ser negativado ("-" antes do valor) use __unm e retorne uma cópia com -x e -y

function Vetor.__add(v1,v2)
    return Vetor.new(v1.x + v2.x,v1.y + v2.y)
end

function Vetor.__sub(v1,v2)
    return Vetor.new(v1.x - v2.x,v1.y - v2.y)
end

function Vetor.__mul(v1,v2)
    if type(v2) == "number" then
        return Vetor.new(v1.x * v2,v1.y * v2)
    end
    return Vetor.new(v1.x * v2.x,v1.y * v2.y)
end

function Vetor.__div(v1,v2)
    if type(v2) == "number" then
        return Vetor.new(v1.x / v2,v1.y / v2)
    end
    return Vetor.new(v1.x / v2.x,v1.y / v2.y)
end

--Desnecessário para operações, somente para leitura humana
function Vetor:__tostring()
    return "x: "..self.x.." y: "..self.y
end

return Vetor